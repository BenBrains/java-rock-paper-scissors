public class Main {
    public static void main(String[] args) {
        SpelController controller = new SpelController();
        SpelController.welcomeMessage();
        Score score = new Score();

        controller.playGame();

    }
}

